List of templates including:
<ul><li>topic-1.html: Used for phase pages (in process)</li>
<li>content-1.html: Used for activities pages</li>

</ul>
<p>All templates are in English only</p>


Location of all images for guide

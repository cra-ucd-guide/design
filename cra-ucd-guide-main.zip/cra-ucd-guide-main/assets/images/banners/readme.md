Folder for banner designs for UCDG

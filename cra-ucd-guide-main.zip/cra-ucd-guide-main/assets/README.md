
Location of all assets including custom CSS/JS, template and image files
